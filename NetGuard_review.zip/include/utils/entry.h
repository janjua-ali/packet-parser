// src/entry.h
#ifndef UTILS_ENTRY_H
#define UTILS_ENTRY_H

int run_entry();

#endif // UTILS_ENTRY_H