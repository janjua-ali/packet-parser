NetGuard

A Modern C++ based Network Intrusion Detection System.
