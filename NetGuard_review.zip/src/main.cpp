#include "utils/entry.h"

int main() {
    return run_entry();  // Just call entry.cpp's main
}